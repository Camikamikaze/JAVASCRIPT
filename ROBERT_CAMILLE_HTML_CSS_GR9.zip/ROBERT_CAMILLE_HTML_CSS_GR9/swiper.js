// slider

document.addEventListener("DOMContentLoaded", function () {
  const swiper = new Swiper(".mon-slider", {
    // Optional parameters
    loop: true,

    // If we need pagination
    pagination: {
      el: ".swiper-pagination",
    },

    // Navigation arrows
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },

    autoplay: {
      delay: 3000,
    },
  });
});

// tab

document.addEventListener("DOMContentLoaded", function () {
  const filterButtons = document.querySelectorAll(".filter-button");
  const filtrItems = document.querySelectorAll(".filtr-item");

  filterButtons.forEach(function (button) {
    button.addEventListener("click", function () {
      const category = this.dataset.filter;
      filtrItems.forEach(function (item) {
        if (category === "all" || item.dataset.category === category) {
          item.style.display = "block";
        } else {
          item.style.display = "none";
        }
      });
    });
  });

  filtrItems.forEach(function (item) {
    const textElement = item.querySelector(
      ".text-empire, .text-rébellion, .text-mandaloriens"
    );
    const button = document.querySelector(
      `[data-filter="${item.dataset.category}"]`
    );

    button.addEventListener("click", function () {
      textElement.style.display = "block";
    });

    item.addEventListener("mouseleave", function () {
      textElement.style.display = "none";
    });
  });
});

// theme sombre
const themebutton = document.querySelector(".themebutton");
themebutton.addEventListener("click", () => {
  const body = document.body;

  body.classList.toggle("dark");
});
